import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Switch, Route} from 'react-router-dom';
import TitlePage from './pages/titlePage';
import ScenePage from './pages/scenePage';
import OptionPage from './pages/optionPage';
// import TitlePage from './pages/titlePage';


function App() {
  return (
    <>
    <Router>
    {/* <div className="App">
       <TitlePage />
    </div> */}
    
                <Switch>
                    <Route exact path="/scenePage">
                          <ScenePage />
                    </Route>
                    <Route exact path="/optionPage">
                        <OptionPage />
                    </Route> 
                      <Route exact path="/">
                      <TitlePage/>
                  </Route>                 
                </Switch>
    </Router>

    </>
  );
}

export default App;
