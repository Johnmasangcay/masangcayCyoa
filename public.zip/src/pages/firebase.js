import { initializeApp } from "firebase/app";
import { getFirestore, collection, getDocs } from 'firebase/firestore/lite';
// import firebase from 'firebase'


const firebaseConfig = {
    apiKey: "AIzaSyDd5kx5-9Bul6A8z4wf7ni_g6cKu8G_cSw",
    authDomain: "reactcyoamasangcayj.firebaseapp.com",
    projectId: "reactcyoamasangcayj",
    storageBucket: "reactcyoamasangcayj.appspot.com",
    messagingSenderId: "1010744420832",
    appId: "1:1010744420832:web:15c2fd79e48c7c0c622385"
  };

  const firebase = initializeApp(firebaseConfig);
  const db = getFirestore();
  const posts = [];
  
  async function getData() {
    // const citiesCol = collection(db, 'CYOA.MASANGCAY');
    // const citySnapshot = await getDocs(CYOA.MASANGCAY);
    // const cityList = citySnapshot.docs.map(doc => doc.data());
    // return cityList;

    const querySnapshot = await getDocs(collection(db, "CYOA.MASANGCAY"));
    querySnapshot.forEach((doc) => {
      posts.push(doc.data());
    });
    return posts;
  }

export {getData, firebase, db}