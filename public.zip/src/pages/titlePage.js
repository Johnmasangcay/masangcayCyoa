import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import { Container, Row, Col, Card, Button, Navbar, NavbarBrand, NavLink, Nav } from 'react-bootstrap';
import OptionPage from "./optionPage";
import { useHistory } from "react-router-dom";

export default function TitlePage(){

    const history = useHistory();
    const toScenePage = () =>{
        console.log(history)
    }

    return(
        <>
        <Container>
            <Row className="title">
            <h1 className=" py-5">Running Dead</h1> 
            </Row>
        </Container>
        
        <Container>
            <Row className="titleBtn">
                <Col>
               <Button className="titleBtn" variant="link" onClick={() => history.push("/scenePage")} >Start Exploring</Button> 
                </Col>
            </Row>
            <Row className="titleBtn pt-3">
                <Col>
               <Button className="titleBtn" variant="link"  onClick={() => history.push("/optionPage")}>Option</Button>
                </Col>
            </Row>
        </Container>

 
        </>
    )
}