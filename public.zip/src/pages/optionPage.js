import React from "react";
import '../App.css';
import { Container, Row, Col, Card, Button, Navbar, NavbarBrand, NavLink, Nav, ButtonGroup } from 'react-bootstrap';

export default function OptionPage(){
    return(
        <div className="optionPageBg">


                        <Navbar bg="dark" variant="dark">
                          <Container>
                           <h3 className="optionTxt">OPTION</h3>
                          </Container>
                      </Navbar>



        <Container>
            <Row className="mediaVol">
                <Col>
                <h3>Media Volume</h3>
                </Col>
            </Row>
            <Row className="mediaVolBtn">
                <Col>
                <ButtonGroup aria-label="Basic example">
                  <Button variant="warning">ON</Button>
                  <Button variant="danger">OFF</Button> 
                </ButtonGroup>
                </Col>
            </Row>
        </Container>
        </div>
    )
}