import React, { useState } from "react";
import { Container, Row, Col, Card, Button, Navbar, NavbarBrand, NavLink, Nav, ButtonGroup } from 'react-bootstrap';
import '../App.css';
import { getData, db } from "./firebase";
// import { useState } from 'react';


export default function ScenePage(){
    //           \to set the Value of the Variable
    let [dataArr, setDataArr] = useState([])

    const getDataFirebase = async(e) =>{
       let arrFirebase = await getData("CYOA.MASANGCAY")
       console.log(arrFirebase)
       setDataArr(arr =>[...arr,arrFirebase])
        setTimeout(() => { 
            console.log(dataArr)
        }, 1000);

       }



    return(
        <div className="scenePageBg">
        <Container>
            <Row>
                <Col>
                <h3 onChange={getDataFirebase}></h3>
                </Col>
            </Row>
            <Row className="btn1">
                <Col md={6}>
                <Button onClick={getDataFirebase} variant="danger">Danger</Button>
                </Col>
                <Col className="btn2" md={6}>
                <Button variant="danger">Danger</Button>
                </Col>
            </Row>
        </Container>
        
        </div>
    )
}